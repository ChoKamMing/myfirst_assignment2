# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect
from .models import User
from django.contrib import messages

def index(request):
    context ={
    "user" : User.objects.all()
    }
    return render(request, 'login_proj_app/index.html', context)
def register(request):
    if request.POST['password'] != request.POST['conpass']:
        messages.error(request, "Passwords does not match")
    else:
        postData = {
            "first_name" : request.POST['first_name'],
            "last_name" : request.POST['last_name'],
            "email" : request.POST['email'],
            "password" : request.POST['password'],
        }
        user_array = User.objects.register(postData)
        #user_array=[False, ['firstname too short', 'password too short']]
        if user_array[0] == False:
            for error_message in user_array[1]:
                messages.error(request, error_message)
            return redirect('/')#redirect back to registration page.
        else:
            return redirect('/')#redirect to success page
def login(request):
    postData = {
    "email" : request.POST['email'],
    "password" : request.POST['password']
    }
    login_errors = User.objects.login(postData)
    if len(login_errors) != 0:
        for error in login_errors:
            messages.error(request, error)
        return redirect('/')
    else:

        return redirect('/')
