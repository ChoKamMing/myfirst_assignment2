from __future__ import unicode_literals
from django.db import models
import re
import bcrypt

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
    def register(self, postData):
        errors = []
        if len(postData['first_name']) < 2:
            errors.append("First name too short")
        if not EMAIL_REGEX.match(postData['email']):
            errors.append('Not valid email')
        if len(postData['password']) < 8:
            errors.append("password too short")
        #if valid return true and the user objects
        if len(errors) == 0:
            hashed_pw = bcrypt.hashpw(postData['password'].encode('utf-8'), bcrypt.gensalt())
            u = User.objects.create(first_name=postData['first_name'], last_name=postData['last_name'], email=postData['email'], password=hashed_pw)
            return [True, u]
        #if not valid return false and an array of the errors
        else:
            return [False, errors]

    def login(self, postData):
        errors = []
        if User.objects.filter(email=postData['email']):
            form_pw = postData['password'].encode()
            db_pw = User.objects.get(email=postData['email']).password.encode()
            if not bcrypt.checkpw(form_pw, db_pw):
                error.append('Incorrect password')
        else:
            errors.append('Email has not been registered')
        return errors




class User(models.Model):
    first_name = models.CharField(max_length=38)
    last_name = models.CharField(max_length=38)
    email = models.CharField(max_length=38)
    password = models.CharField(max_length=38)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

    def __unicode__(self):
        return "id:" + str(self.id) + "first name" + self.first_name + "last name" + self.last_name + "email" + self.email + "password" + self.password 
